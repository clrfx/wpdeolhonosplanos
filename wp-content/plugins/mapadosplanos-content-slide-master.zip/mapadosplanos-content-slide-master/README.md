# Content Slide Wordpress Plugin

Plugin originalmente disponível em [http://wordpress.org/extend/plugins/content-slide/](http://wordpress.org/extend/plugins/content-slide/).
