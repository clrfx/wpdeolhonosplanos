=== WPSP - Terms of Use ===
Contributors: WP Simple Plugins
Donate link: http://www.wp-simple-plugins.com
Tags: register, registration, terms of use, terms and conditions, wpsp
Requires at least: 3.1
Tested up to: 3.2.1
Stable tag: 1.0

WPSP - Terms of Use plugin is a plugin that links to the websites Terms of Use on the user registration page.

== Description ==

WPSP - Terms of Use plugin is a plugin that links to the websites Terms of Use on the user registration page. The user must agree to the Terms of Use before being allowed to register for the website.

== Installation ==

To install WPSP - Terms of Use via regular WordPress 

1. Unzip the downloaded 'wpsp-terms-of-use' zip file
2. Upload the 'wpsp-terms-of-use' folder to '/wp-content/plugin' directory of your WordPress installation
3. Activate the plugin via the WordPress Plugins page

== Frequently Asked Questions ==

None yet

== Upgrade Notice == 

None yet

== ChangeLog ==

= Version 1.0 =
* Initial release

== Screenshots ==

1. WPSP - Terms of Use settings page
2. Registration page with Terms of Use enabled