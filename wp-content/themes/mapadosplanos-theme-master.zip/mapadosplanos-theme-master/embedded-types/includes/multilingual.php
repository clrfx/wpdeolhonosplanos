<?php
/* 
 * Multilingual functions.
 * 
 * @since Types 1.1.3.2
 */

function wpcf_translate_slugs($type = 'post') {
    switch ($type) {
        case '__add_here_other_slug_handling':


            break;

        default:
            
            break;
    }
}

function wpcf_translate_slugs_form($type = 'post', $form = array()) {
    $_form = array(
        ''
    );
    switch ($type) {
        case '__add_here_other_slug_handling':


            break;

        default:
            
            break;
    }
}